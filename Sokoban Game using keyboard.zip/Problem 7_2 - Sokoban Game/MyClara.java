/**
 * MyClara is a subclass of Clara. Therefore, it inherits all methods of Clara: <p>
 * 
 * 
 * PERMITTED COMMANDS
 * Actions:     move(), turnLeft(), turnRight(), putLeaf(), removeLeaf()
 *              mushroomFront(), canPushMushroom(), setNumberOfMoves(),
 *              testLevelComplete(), setDirectionUp(), setDirectionDown(),
 *              setDirectionLeft(), setDirectionRight(), getKey()
 * Sensors:     onLeaf(), treeFront(), mushroomFront()
 * JAVA:        if, else, while, for, !, &&, ||
 */
class MyClara extends Clara
{
    int Count =0;
    //We declare a variable "Count"
    int Moves =0;
    //We declare a variable "Moves"
    
;
    public void act()
    {

        movement();
        //Calling movement method

        if (testLevelComplete()) 
        {
            Count++;
        }

        if(Count==1)
        {
            levelComplete();
            Count++;
        }
        //Command to pop up the level complete dialogue box when the level gets completed 

    }


    public void levelComplete()
    {
        showWarning("Level Complete!");
    }
    //Method to print the Level Complete 

    void movement()
    {
        setNumberOfMoves(Moves);        

        String keyPressed = getKey();

        if (keyPressed == "down")
        {
            setDirectionDown();
            avoidCrashing();
            Moves++;
            
        }
        //Method for clara to move down when the down arrow key is pressed. 
        if (keyPressed == "right")
        {
            setDirectionRight();
            avoidCrashing();
            Moves++;
        }
        //Method for clara to move right when the right arrow key is pressed. 
        if (keyPressed == "left")
        {
            setDirectionLeft();
            avoidCrashing();
            Moves++;
        }
        //Method for clara to move left when the left arrow key is pressed. 
        if (keyPressed == "up")
        {
            setDirectionUp();
            avoidCrashing();
            Moves++;
        }
        //Method for clara to move up when the up arrow key is pressed. 

    }

    void avoidCrashing()
    {
        if (!treeFront() && !mushroomFront())
        {
            move();
           
        }
        //Command for clara to prevent her from crashing into the tree. 

        else if (mushroomFront())
        {
            if (canPushMushroom())
            {
                move();
              
            }
        }
        //Command for clara to prevent her from crashing into the tree while pushing the mushroom. 

    }

}