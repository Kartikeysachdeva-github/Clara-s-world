/* PERMITTED COMMANDS
   move(); turnLeft(); putLeaf(); removeLeaf();
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void Right() {
        turnLeft();
        turnLeft();
        turnLeft();
    
        // TODO: Write your code below
    }
        // My name is Kartikey Sachdeva (KS)
    
        void run() {
            move();
            Right();
            move();
            move();
            removeLeaf();
            move();
            removeLeaf();
            move();
            removeLeaf();
            move();
            removeLeaf();
            move();
            removeLeaf();
            move();
            removeLeaf();
            move();
            removeLeaf();
            Right();
            Right();
            move();
            move();
            move();
            Right();
            move();
            removeLeaf();
            turnLeft();
            move();
            Right();
            move();
            removeLeaf();
            turnLeft();
            move();
            Right();
            move();
            removeLeaf();
            turnLeft();
            move();
            Right();
            move();
            removeLeaf();
            turnRight();
            move();
            move();
            move();
            move();
            move();
            move();
            removeLeaf();
            turnRight();
            move();
            turnRight();
            move();
            removeLeaf();
            turnLeft();
            move();
            turnRight();
            move();
            removeLeaf();
            move();
            move();
            move();
            move();
            turnRight();
            move();
            move();
            move();
            move();
            removeLeaf();
            move();
            removeLeaf();
            move();
            removeLeaf();
            move();
            removeLeaf();
            turnRight();
            turnRight();
            move();
            move();
            move();
            turnLeft();
            move();
            removeLeaf();
            move();
            removeLeaf();
            move();
            removeLeaf();
            turnLeft();
            move();
            removeLeaf();
            move();
            removeLeaf();
            move();
            removeLeaf();
            turnRight();
            move();
            removeLeaf();
            move();
            removeLeaf();
            move();
            removeLeaf();
            turnRight();
            move();
            removeLeaf();
            move();
            removeLeaf();
            move();
            removeLeaf();








    
        }
    

}

