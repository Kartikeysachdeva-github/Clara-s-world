/* PERMITTED COMMANDS
   move(); turnLeft(); putLeaf(); removeLeaf();
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below 
        turnLeft();
        turnLeft();
        turnLeft();
        move();
        turnLeft();
        move();
        move();
        move();
        move();
        move();
        move();
        turnLeft();
        move();
        move();
        move();
        removeLeaf();
        turnLeft();
        turnLeft();
        move();
        move();
        move();
        turnLeft();
        turnLeft();
        turnLeft();
        move();
        move();
        move();
        move();
        move();
        move();
        turnLeft();
        move();
        putLeaf();
        turnLeft();
        turnLeft();
        move();
        move();

    }
}