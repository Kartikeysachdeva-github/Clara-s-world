/* PERMITTED COMMANDS
   move(); turnLeft(); putLeaf(); removeLeaf();
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        move();
        turnLeft();
        turnLeft();
        turnLeft();
        move();
        move();
        move();
        move();
        turnLeft();
        move();
        move();
    }
}