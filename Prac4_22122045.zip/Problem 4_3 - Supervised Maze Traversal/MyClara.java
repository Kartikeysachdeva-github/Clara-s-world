/* PERMITTED COMMANDS
   Clara commands:
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf(); mushroomFront();
   JAVA commands:
   if, while, for, do, !, ||, &&
    */

class MyClara extends Clara {
    /**
     * In the 'run()' function you can write your program for Clara 
     */
    void run() {

        removeLeaves();
        //clara will dodge obstacles and remove leaves along her way using this command. 
    }

    void removeLeaves()
    {
        while (onLeaf())
        //clara will moves only while she's on a leaf using this command. 

        {
            removeLeaf();
            //clara will remove leaf using this command. 
            move();
            //clara will initiate moving uisng this command.  

            if (treeFront() && !treeRight())
            {
                turnRight();
            }
            //clara will turn right if she faces a tree front and no tree on her right using this command. 

            if (treeFront() && !treeLeft())
            {
                turnLeft();
            }
            //clara will turn left if she faces a tree front and no tree on her left using this command.  

        }

        if(!treeRight())
        {
            turnAround();
        }

        else turnLeft();
        //clara will turn around only when there is no tree on her right using this command. 
        //if there's a tree on her right, she will turn left. 

        move();
        //clara will initiate moving using this command. 

        if (!treeRight())
        {
            turnRight();
        }
        //clara will turn right if there's no tree on her right using this command. 

        while (!mushroomFront())
        {
            move();

            if (onLeaf())
            {
                removeLeaf();
            }
        }
        //clara will move until she faces a mushroom front and remove leaves on her way using this command. 


    }

    void turnAround()
    {
        turnLeft();
        turnLeft();
    }
    //clara can turn around directly using this command. 

}