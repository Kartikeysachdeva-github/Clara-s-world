/* PERMITTED COMMANDS
   Clara commands:
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf(); mushroomFront();
   JAVA commands:
   if, else, for, while, do, &&, ||, ! */
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
     //The goal is to make clara put leaves on her way and reach the mushroom.
    void run() {

        while (!mushroomFront())
        //Clara can move on her own until she reaches the mushroom using this command.
        {
            wonderMazeAndPutLeaves();
            //Clara can wonder around the maze without crashing into anything using this command.
            move();
            //To initiate clara to move
        }

        putLeaf();
        //To make clara put a leaf infront of the mushroom.
    }

    void wonderMazeAndPutLeaves()
    {

        if (treeFront()&&!treeLeft())
        {
            turnLeft();
        }
        //If clara faces no tree on her left and a tree front, she will turn left using this command.

        if(!onLeaf())
        {
            putLeaf();
        }
        //Clara will put leaf if she's not standing on a leaf using this command.
    }
}