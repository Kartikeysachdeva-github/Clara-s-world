/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/

class MyClara extends Clara {
    /**
     * In the 'run()' method you can write your program for Clara 
     */

    //goal is to fill all the spots with clara's leaves. To initiate the code use move() command.   


    void run() {
        move();
        putLeaves();
        putLeaf();  
    }
    // The "putLeaves()" command is made for clara to understand the situations while putting leaves.

    void turnAround()
    //The turnAround command. 
    {
        turnRight();
        turnRight();
    }

 
    void putLeaves()
    //The putLeaves command.    
    {
        while (!mushroomFront())
        //A while loop is made for clara to move on her own till she reaches the mushroom. 

        {
            if (!onLeaf())
            {
                putLeaf();
            }
            //In the while loop if clara is not on a leaf she will put a leaf with this command. 

            if (!treeRight() && !treeLeft() && !treeFront())
            {
                turnLeft();
            }
            //If clara does not face any tree on her left or right or front, she will turn left with this command.

            move();
            // clara will move after thinking about the situations above.             

            if (treeFront() && treeRight() && treeLeft())
            {
                turnAround();
            }
            //If clara faces a tree on her left and right and front, she will turn around with this command. 

            if (treeFront() && !treeRight())
            {
                turnRight();

            }
            //If clara faces a tree on her front and no tree on her right, she will turn right using this command.

            if (treeFront() && !treeLeft())
            {
                turnLeft();
            }
            //If clara faces a tree front and no tree on her left, she will turn left using this command. 



        }
    }
}