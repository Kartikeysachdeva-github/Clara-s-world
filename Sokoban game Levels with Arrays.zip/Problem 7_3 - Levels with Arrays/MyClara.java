/**
 * MyClara is a subclass of Clara. Therefore, it inherits all methods of Clara: <p>
 * 
 * 
 * PERMITTED COMMANDS
 * Actions:     move(), turnLeft(), turnRight(), putLeaf(), removeLeaf()
 *              mushroomFront(), canPushMushroom(), setNumberOfMoves(),
 *              testLevelComplete(), setDirectionUp(), setDirectionDown(),
 *              setDirectionLeft(), setDirectionRight(), getKey()
 * Sensors:     onLeaf(), treeFront(), mushroomFront(), loadLevel()
 * JAVA:        if, else, while, for, !, &&, ||
 */
class MyClara extends Clara 
{
     private char[][] level1 = {
		{'#', '#', '#', '#', ' ', ' ', ' ', ' ', ' ', ' '},
        {'#', ' ', '|', '#', ' ', ' ', ' ', ' ', ' ', ' '},
        {'#', ' ', ' ', '#', '#', '#', ' ', ' ', ' ', ' '},
        {'#', ' ', '@', ' ', ' ', '#', ' ', ' ', ' ', ' '},
        {'#', ' ', ' ', '$', ' ', '#', ' ', ' ', ' ', ' '},
        {'#', ' ', ' ', '#', '#', '#', ' ', ' ', ' ', ' '},
        {'#', '#', '#', '#', ' ', ' ', ' ', ' ', ' ', ' '}
    };
    
     private char[][] level2 = {
        {'#', '#', '#', '#', '#', ' ', ' ', ' ', ' '},
        {'#', '@', ' ', ' ', '#', ' ', ' ', ' ', ' '},
        {'#', ' ', '$', '$', '#', ' ', '#', '#', '#'},
        {'#', ' ', '$', ' ', '#', ' ', '#', '|', '#'},
        {'#', '#', '#', ' ', '#', '#', '#', '|', '#'},
        {' ', '#', '#', ' ', ' ', ' ', ' ', '|', '#'},
        {' ', '#', ' ', ' ', ' ', '#', ' ', ' ', '#'},
        {' ', '#', ' ', ' ', ' ', '#', '#', '#', '#'},
        {' ', '#', '#', '#', '#', '#', ' ', ' ', ' '},
    };
    
     private char[][] level3 = {
        {'#', '#', '#', '#', '#', '#', ' '},
        {'#', ' ', ' ', ' ', ' ', '#', ' '},
        {'#', ' ', '#', '@', ' ', '#', ' '},
        {'#', ' ', '$', '*', ' ', '#', ' '},
        {'#', ' ', '|', '*', ' ', '#', ' '},
        {'#', ' ', ' ', ' ', ' ', '#', ' '},
        {'#', '#', '#', '#', '#', '#', ' '},
    };

    static int currentLevel =0;
    //We declare a variable "current variable"
    int Moves =0;
    //We declare a variable "Moves"
    int Count =0;    
    //We declare a variable "Count"

    public void act() 
    {
        setNumberOfMoves(Moves);
        //Commnad to count the number of times clara moves. 
        movement();
        //Calling the "moment" method

    if (currentLevel <4)
    {
        if (testLevelComplete()) 
        {
            showWarning("Level Completed!");
            currentLevel++;
            changeLevels();   
            //Calling the changeLevels command. 
        }
    } 
    //Command to pop up the level complete dialogue box
   
    }

    void changeLevels()
    {       
        if(currentLevel==1)
        {
            loadLevel(level1);
        }
        if(currentLevel==2)
        {
            loadLevel(level2);
        }
        if(currentLevel==3)
        {
            loadLevel(level3);
        } 
    }
    //Method to change the levels once the level is completed. 

       void movement()
    {

        String keyPressed = getKey();

        if (keyPressed == "down")
        {
            setDirectionDown();
            avoidCrashing();
            Moves++;    
        }
        //Method for clara to move down when the down arrow key is pressed. 
     
        if (keyPressed == "right")
        {
            setDirectionRight();
            avoidCrashing();
            Moves++;
      
        }
        //Method for clara to move right when the right arrow key is pressed. 
      
        if (keyPressed == "left")
        {
            setDirectionLeft();
            avoidCrashing();
            Moves++;
         
        }
        //Method for clara to move left when the left arrow key is pressed. 
     
        if (keyPressed == "up")
        {
            setDirectionUp();
            avoidCrashing();
            Moves++;
           
        }
        //Method for clara to move up when the up arrow key is pressed. 

    }

    void avoidCrashing()
    {
        if (!treeFront() && !mushroomFront())
        {
            move();
           
        }
        //Command for clara to prevent her from crashing into the tree. 

        else if (mushroomFront())
        {
            if (canPushMushroom())
            {
                move();
              
            }
        }
        //Command for clara to prevent her from crashing into the tree while pushing the mushroom. 

    }
}