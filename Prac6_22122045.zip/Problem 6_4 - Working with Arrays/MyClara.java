/* PERMITTED COMMANDS 
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront,
   addTree(x, y),
   JAVA
   if, while, for, do, &&, !, ||, variables, arrays
*/

class MyClara extends Clara {

    void run() {

        drawTriangle();
        //Calling command to plant trees and make stairs for clara. 
        getLeaf();
        //Calling command to to get the leaf. 
        returnBack();
        //Calling command for clara to return back. 

    }

    void drawTriangle()
    {
        int[][] stairs = {
            {0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,1,0,0,0,0,0},
            {0,0,0,0,1,1,1,0,0,0,0},
            {0,0,0,1,1,1,1,1,0,0,0},
            {0,0,1,1,1,1,1,1,1,0,0},
            {0,1,1,1,1,1,1,1,1,1,0},
            {1,1,1,1,1,1,1,1,1,1,1},
        };
        //We initialize a 2D array to plant trees to represent a triangle.
        //For each 1 in the array, clara will plant a tree.  

        for(int p=0; p<stairs.length;p++)
        {
            for(int j=0; j<stairs[p].length;j++)
            {
                if(stairs[p][j]==1)
                {
                    addTree(j,p);
                }
            }
        }
        //Command for clara to read the array. If the value is 1 at the current postion. Clara will plant  a tree using addTree on the current coordinates.
    }

    void getLeaf()
    {
        while(!onLeaf())
        {
            reposition();
            move();
        }
        //While clara is not on leaf, she will climb the stairs using repostion and move. 

        removeLeaf();
        turnAround();
        //Clara will remove the leaf from the top and turn around. 

    }

    void returnBack ()
    {
        for (int e=0; e<5; e++)
        {
            move();
            reposition();
        }        
    }
    //Clara will return to her initial position using this method. 

    void turnAround()
    {
        turnRight();
        turnRight();
    }
    //Clara will turn around using this method. 

    void reposition()
    {
        turnLeft();
        move();
        turnRight();
    }
    //Clara will climb the stairs using this method. 
}