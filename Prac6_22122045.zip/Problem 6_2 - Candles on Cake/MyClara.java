/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/

class MyClara extends Clara {
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    int Width = 0;
    int Height = 0;
    //This command declares the height and width of the cake. 
    

    void run() {

        Height = readInt("Enter the height of the cake:");
        //Clara ask's the height of the cake using this command. 

        while (Height > 10)
        {
            Height = readInt("Number less than 11 expected , Re-enter the height of the cake:");
        }
        //She asks to re-enter the height less than 11.

        
        Width = readInt("Enter the Width of the cake:");
        //Clara ask's the width of the cake using this command. 

        while (Width > 17)
        {
            Width = readInt("Number less than 18 expected , Re-enter the width of the cake:");
        }
        //She asks to re-enter the height less than 11. 

        cake();
        //Call the method to create the cake. 
    }




    void cake()
    {

        for (int i = 0; i < Height; i++)
        //Clara decides the height of the cake and start making it using this command . 
        {
            for (int o = 0; o < Width; o++)
            {
                safeMove();
            }
            //Clara decides the width of the cake  and start filling the base with the leaves using this command.
            turnAround();

            for (int o = 0; o < Width; o++)
            {
                safeMove();
            }
            reposition();
            //Clara starts filling the width again after turning around and repositioning using this command.

        }

        candles();
        //Calls the command to make the candles. 

    }

    void turnAround()
    {
        turnRight();
        turnRight();
    }
    //Command for clara to turn around. 

    void safeMove()
    {
        if (!onLeaf())
        {
            putLeaf();
        }

        move();
    }
    //This command will make clara put leaf only on the spaces where there is no leaf. 

    void reposition()
    {

        turnRight();
        move();
        turnRight();

    }
    //This command helps Clara to change rows to make the cake. 

    void candles()
    {
        for (int o = 0; o < Width/2; o++)
        // This command makes clara place candles along half of the cake's width. 
        {
            move();

            turnLeft();
            //Turns left to start making the candle using leaves. 

            for (int p = 0; p < 3; p++)
            {
                safeMove();
            }
            //Make clara make a candle using 3 leaves. 

            turnAround();
            //Turns around after reaching the top of the candle. 
            for (int p = 0; p < 3; p++)
            {
                move();
            }
            //Repeats the command to help clara return to the top layer of the cake.  

            turnLeft();
            move();
            //Turn left again to make more candles


        }
    }

}