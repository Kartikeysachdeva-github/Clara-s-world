/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/

class MyClara extends Clara {
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {

        int Height = readInt("Enter the height of the cake:");
        //Clara ask's the height of the cake using this command.

        while (Height > 13)
        {
            Height = readInt("Number less than 14 expected , Re-enter the height of the cake:");
        }
        // she asks to re-enter the height less than 14.

        int Width = readInt("Enter the Width of the cake:");
        //Clara ask's the width of the cake using this command.

        while (Width > 17)
        {
            Width = readInt("Number less than 18 expected , Re-enter the width of the cake:");
        }
         //She asks to re-enter the height less than 18.

        for (int i = 0; i < Height; i++)
        //Using this command, clara will make the height of the cake according to the value given.
        {
            for (int k = 0; k < Width; k++)
            //Using this command, clara will make the width of the cake according to the value given. 
            {
                putLeaf();
                move();
            }
            //Clara will start making cake by putting leaves after this command.
            

            if (i % 2 == 0)
            {
                repositionToWest();
            }

            else repositionToEast();

            //Clara will repostion to the new line after she is done scaling the width of the cake using the command above.
        }

    }

    void repositionToWest()
    {
        putLeaf();
        //Clara will put a leaf in the end using this command. 
        turnLeft();
        move();
        turnLeft();
    }
    //Clara will reposition to the West using this command. 

    void repositionToEast()
    {
        putLeaf();
        //Clara will put a leaf in the end using this command. 
        turnRight();
        move();
        turnRight();
    }
    //Clara will reposition to the West using this command.

}