/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/

class MyClara extends Clara {
    /**
     * In the 'run()' method you can write your program for Clara 
     */

    int Age = 0;
    //Declare Age variable

    void run() {

        cake();
        //Calling the "cake" method

        Age = readInt("Enter your age:");
        //Clara asks for the age to make candles. 

        candles();
        //Calling "candles" method. 

    }


    void cake()
    {

        for (int i = 0; i < 4; i++)
        {
            for (int o = 0; o < 17; o++)
            {
                safeMove();
            }
            turnAround();

            for (int o = 0; o < 17; o++)
            {
                safeMove();
            }
            reposition();

        }

    }
    //Clara builds the cake using the command above. 

    void turnAround()
    {
        turnRight();
        turnRight();
    }
    //Clara can turn around using this command. 

    void safeMove()
    {
        if (!onLeaf())
        {
            putLeaf();
        }

        move();
    }
    //Clara put leaves on her way to make the cake using this command. 

    void reposition()
    {

        turnRight();
        move();
        turnRight();

    }
    //Clara repositions to the row above using this code. 

    void candles()
    {

        for (int a = 0; a < (17 - (Age / 10) * 2) / 2; a++)
        {
            move();
        }
        //Clara puts the candles in the center of the cake using this command. 

        for (int o = 0; o < Age / 10; o++)
        {

            move();

            turnLeft();
            //Clara turn left to make candles using this command. 

            for (int p = 0; p < Age / 10; p++)
            {
                safeMove();
            }

            turnAround();

            for (int p = 0; p < Age / 10; p++)
            {
                move();
            }
            //After making the candle, Clara returns to the cake using this command. 

            turnLeft();
            move();


        }
    }


}