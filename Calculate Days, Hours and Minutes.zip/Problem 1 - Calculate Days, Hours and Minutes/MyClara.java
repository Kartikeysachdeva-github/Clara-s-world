/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/

class MyClara extends Clara {



    int Days = 0;
    int Hours = 0;
    int Minutes = 0;
    int Seconds = 0;

    
    void run() {

        Seconds = readInt("Enter the number of seconds:");

        Days = Seconds/(60*60*24);
        Seconds = Seconds % (60*60*24);

        System.out.println("Number of days:" + Days);

        Hours = Seconds/(60*60);
        Seconds = Seconds % (60*60);

        System.out.println("Number of Hours:" + Hours);

        Minutes = Seconds/60;

        System.out.println("Number of Minutes:" + (Seconds / 60));
        
        Seconds = Seconds % 60;

        System.out.println("Number of Seconds:" + Seconds);


    }


}