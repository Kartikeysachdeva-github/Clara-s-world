/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/

class MyClara extends Clara {
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {

        boolean facingEast = true;
        //we put a boolean variable "facingEast" as true.
        while (!treeFront())
        //we make a while command for clara for when she doesn't face a tree on front.

        {
            putLeavesSimultaneously();
            //command for clara to put leaves while leaving a space in between.

            if (facingEast && treeFront() && !treeLeft())
            {
                repositionToWest();
                facingEast = false;
            }
            /*If there's tree front and no tree on left and clara is facing east, she will repostion to east
            and put the boolean "facingeast" false as the next time she faces a tree front, she would also be facing west.*/

            if(!facingEast && treeFront() && !treeRight())
            {
                repositionToEast();
                facingEast = true;
            }
            /*If clara is not facing west and facing a tree front with no tree on the right, she will reposition to east 
            and the boolean "facingEast" will be set  true as the next time she faces a tree front, she would also be facing east.*/

        }

    }

    void putLeavesSimultaneously()
    {
        while (!treeFront())
        {
            putLeaf();
            move();
            safemoves();
        }
        //Using this command clara will put leaves while leaving a space in between till she faces a tree front.

    }

    void repositionToWest()
    {
        turnLeft();
        safemoves();
        turnLeft();
    }
    //using this command clara will reposition to east when she faces a tree front. 

    void repositionToEast()
    {
        turnRight();
        safemoves();
        turnRight();
    }
    //Using this command clara will repostion to west when she faces a tree front.

    void safemoves() 
    {
        if (!treeFront())
            move();
    }
    //Using this command, clara will only movee if there is no tree front.
}