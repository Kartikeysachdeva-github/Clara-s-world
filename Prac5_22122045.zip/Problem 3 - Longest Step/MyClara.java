/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/

class MyClara extends Clara {

    void run() {

        int longestStep = 0;
        //The initial value of the longest step will be 0 using this command.
        int steps = 0;
        //The intial value of the steps will be 0 using this command. 

        while(!onLeaf())
        //Clara will move until she is not on a leaf using this command.
        {

            while(!treeFront())
            //Clara will move while she faces no tree front using this command. 
            {
            steps=steps+1;
            //Clara will count her steps starting from 0 using this command.
            move();
            //To initialise clara to move. 
            }

            if (treeFront()&&!onLeaf())
            {

                turnLeft();
                move();
                turnRight();
                
            }
            //If clara is not on leaf and she faces a tree front, she will turn left, move and turn right to reposition above the tree.

            if (steps>longestStep)
            {
                longestStep=steps;
            }
            //If the steps are more than longest step, the steps will be put equal to longest step using this command.

            steps=0;
            //After that the steps will be reloaded to 0 using this command.

        }
         removeLeaf();
         //This command will be used to remove the final leaf. 
        System.out.println("longest step = "+longestStep);
        //This command will print the longest step in the console. 
    }
    

}