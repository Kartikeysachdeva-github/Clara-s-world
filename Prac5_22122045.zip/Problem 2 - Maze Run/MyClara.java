/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/

class MyClara extends Clara {
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {

        boolean turnRightInTheEnd;
        //we put a boolean datatype to make her decide where she should turn at the end. 

        while (!mushroomFront())
        {

            if (onLeaf())
            {
                turnRightInTheEnd = true;
                removeLeaf();
            }
            //If clara is on leaf, she fill remove the leaf and move right at the end of the road as the boolean variable is stated as true.

            else
            {
                turnRightInTheEnd = false;
            }
            //If clara is not on leaf, she will turn left instead as the boolean variable is stated as false.

            while (!treeFront()&&!mushroomFront())
            {
                move();
            }
            //While no tree front and no mushroom front, clara will keep on moving. 

            if (turnRightInTheEnd)
            {
                turnRight();
            }
            //This command gives the command to follow to the boolean. If the "turnRightInTheEnd" is true, clara will turn right in the end.
            else
            {
                if (!mushroomFront())
                {
                    turnLeft();
                }
            }
            //If the turn right command is false, she will turn left instead using this  command. 

        }

    }

}