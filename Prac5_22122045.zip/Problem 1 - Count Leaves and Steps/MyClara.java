/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/

class MyClara extends Clara {
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {

        int steps = 0;
        //the initial value of the steps will be 0 using this command. 
        int leaves = 0;
        //the initial value of the leaves will be 0 using this command. 


        while (!treeFront())
        //clara will move until she faces a tree front using this command. 
        {

            if (onLeaf())
            {
                leaves = leaves+1;
                //clara will count the number of leaves using this command. 
                removeLeaf();
                //clara will remove leaf using this command.

            }

            steps = steps+1;
            //clara will count the number of steps using this command. 
            move();
            //clara will move using this command. 

            if (!treeRight())
            {
                turnRight();
            }
            //clara will turn right if there's no tree on her right using this command. 

        }

        removeLeaf();
        //clara will remove the last leaf using this command. 
        leaves = leaves+1;
        //clara will count the last leaf using this command. 

        System.out.println(leaves + " leaves, " + steps + " steps");
        //this command prints put the number of steps and leaves. 


    }

}