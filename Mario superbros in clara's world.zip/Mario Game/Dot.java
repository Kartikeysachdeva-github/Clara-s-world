/**
 * Dot Class
 * 
 * Available methods (see Assignment document for explanations on what each method does):
 * onEarth
 * setDirection,
 * move(speed),
 * animate, animateInvisible,
 * intersects(Character), intersectsWithName(String)
 * moveToClara
 * wrapAroundWorld
 * playShotSound
 */
class Dot extends Character {

    public static boolean BulletVisible;
    //boolean to check if the bullet is visible or not
    public static boolean moveForward;
    //boolean to make the bullet move forward.
    int recoil = 0;
    //Declaring an int for recoil and shoot delay. 
    int life = 0;
    //Declaring an int for bullet life. 

    public void act()
    {
        Bullet();
        //calling the bullet method
    }

    public void Bullet()
    {
        recoil++;
        //Incrementing reload. 
        life++;
        //Incrementing life. 

        if (moveForward == true && life<=120)
        {
            if (!onEarth())
            {
                move(5);
            }
            else BulletVisible = false;
        }
        //using this method, the bullet will move forward if there's no earth front. 

        if (BulletVisible == true && life <=120)
        {
            animate();
        }
        else animateInvisible();
        //using this command, the bullet will be visible when fired. 


        if (Keyboard.isKeyDown("s") && MyClara.dead == false && recoil>=130)
        {
            life = 0; 
            //Declaring life is equals to 0. 
            recoil=0;
            //Declaring recoil as 0 after everytime the bullet is shot. 

            moveToClara();
            //using this command, the bullet will move to clara automatically. 
            moveForward = true;
            //making the move condition true when the s key is pressed. 
            BulletVisible = true;
            //making the bullet visible when fired. 

            if (MyClara.isClaraFacingLeft == true)
            {
                setDirection("left");
            }
            else setDirection("right");
            //using this command, the bullet will go in the same direction as clara, when fired. 

            if (earthBelow())
            {
                moveForward = true;
                move(5);
                playShotSound();
            }
            //The bullet will move when there is earth below using this command. 
        }

    }
    //Method for clara to shoot bullets if the s key is pressed and if she is alive.


}