/**
 * MyClara
 * 
 * Available methods (see Assignment document for explanations on what each method does):
 * getDirection, setDirection,
 * move,
 * animate, animateDead, 
 * onLeaf, removeLeaf, 
 * onEarth,
 * allLeavesEaten,
 * isClaraDead,
 * playCollectLeafSound,
 * playIntro, isIntroStillPlaying,
 * playJumpSound, playLevelFinishedSound,
 * isLevelFinishedSoundStillPlaying
 * wrapAroundWorld,
 * getCurrentLevelNumber, advanceToLevel
 */
class MyClara extends Clara
{
    public final char[][] LEVEL_1 = {
    {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
    {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
    {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
    {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
    {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
    {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','~','%','.','.',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
    {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','~','~','~','~',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
    {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','.','%','~',' ',' ',' ',' ',' ',' ',' ',' ','.',' ',' ',' ',' ',' ',' ',' ',' '},
    {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','~','~','~','~','~',' ',' ',' ',' ',' ',' ','~','~','~','~',' ',' ',' ',' ',' ',' ',' '},
    {' ',' ',' ',' ',' ',' ',' ','.','.',' ',' ',' ',' ','~','.','.','%',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
    {' ',' ',' ',' ',' ',' ','~','~','~','~',' ',' ',' ','~','~','~','~',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
    {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
    {'~','@','-',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ', ' ',' ',' ',' ',' ',' ','.',' ',' ',' ',' ',' ','~','~','~',' ',' ','.',' ','$','~'},
    {'~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~','~'}
    };  

    public final String  UP = "up";    
    public final String  DOWN = "down";    
    public final String  LEFT = "left";    
    public final String  RIGHT = "right";

    final int JUMP_VELOCITY_X = 1;
    final int JUMP_VELOCITY_Y = 2;
    final int GRAVITY_X = 0;
    final int GRAVITY_Y = -1;
    int currentX = 0;
    //Declaring an int to store the current position of clara on x axis. 
    int X =0;
    //Declaring an int X. 
    int Y =0;
    //Declaring an int Y. 
    int A = 0;  
    //Declaring an int A for animation.   
    int AllowIntro= 2;    
    //Declaring an int to allow intro
    int IncrementLevel = 0;
    //Declaring an int to change the level. 
    public static boolean isClaraFacingLeft; 
    //Declaring a boolean to check if clara is facing left or not for other classes. 
    public static boolean dead;   
    //Declaring a boolean to check to check if she is dead for other classes.

    public void act()
    {
        if(isClaraDead()==true)
        {
            animateDead();
        }
        //if Clara is not dead, she will animate. 

        introAndChangeLevel();
        //Calling the method to play intro and change level.

        controls();
        //Calling the method for clara to move. 

        collectCoins();
        //Calling the method to collect coins(leaves). 
    }

    int jump(int inOriginalX, int inVelocityX, int inVelocityY)
    {
        int posY = Y;
        //storing posY in Y. 
        int posX = 0;
        //Declaring posX is equals to 0.

        if(getDirection() == "left")
        {
            inVelocityX = inVelocityX*-1;
        }
        else
        {
            inVelocityX = inVelocityX*1;
        }
        //Using this command, clara will set direction before jumping. 

        do
        {
            posX += inVelocityX;
            posY += inVelocityY;

            changePosition(currentX, posX, posY);
            collectCoins();

            inVelocityX = inVelocityX + GRAVITY_X;
            inVelocityY = inVelocityY + GRAVITY_Y;
        }
        while ( posY > 0 && !earthBelow() && !onEarth() );

        X=posX;
        //Storing posX in X. 
        Y=posY;
        //Storing posY in Y. 

        return inOriginalX + posX;
        //Above method, helps clara to jump and collect coins. 

    }
    //Method to help clara jump. 

    
      public void controls()
    {
        if(isClaraDead()==false)
        {
       if (Keyboard.isKeyDown("down"))
        {
            setDirection("down"); 
            avoidCrashing();     
        }
        //Method for clara to move down when the down arrow key is pressed. 
     
        if (Keyboard.isKeyDown ( "right"))
        {
            setDirection("right");
            isClaraFacingLeft=false;
            avoidCrashing();
            X++;     
        }
        //Method for clara to move right when the right arrow key is pressed. 
      
        if (Keyboard.isKeyDown ("left"))
        {
            setDirection("left");
            isClaraFacingLeft=true;
            avoidCrashing();
            X--;    
        }
        //Method for clara to move left when the left arrow key is pressed. 

        if (Keyboard.isKeyDown("up")) {
            currentX = jump(currentX, JUMP_VELOCITY_X, JUMP_VELOCITY_Y);
        }
        //Method for clara to jump when the up arrow key is pressed. 

        if(!earthBelow())
        {
            setDirection("down");
            move();
            Y--;
        }
        //Method for clara to stay under the effect of gravity. 

        animateClara();
        //Calling the command to animate clara. 

        }
    }
    //Method for clara to control her moments. 

    public void introAndChangeLevel()
    {
        if(AllowIntro>0&&isClaraDead()==false)
        {
            playIntro();
        }
        //Method for clara to play intro. 

       if(mushroomFront()&&allLeavesEaten()==true)
       {
           AllowIntro = 0;
           IncrementLevel++;
           playLevelFinishedSound();
           advanceToLevel(LEVEL_1);
       }
       //Method for clara to change level

    }

    public void animateClara()
    {
       A++;

        if(A%12==0)
        {
            animate();
        }
    }
    //Method to animate clara. 

    void avoidCrashing()
    {
        if(!earthFront())
        {
            move();
        }
    }
    //Method for clara to avoid crashing. 

    void collectCoins()
    {
        if(onLeaf())
        {
            removeLeaf();
            playCollectLeafSound();
        }
    }
    //Mehtod for clara to collect coins/leaves. 

}