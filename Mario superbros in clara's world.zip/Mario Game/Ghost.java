/**
 * Ghost Class
 * Available methods (see Assignment document for explanations on what each method does):
 * earthFront
 * getDirection, setDirection,
 * move(speed),
 * animate, animateDead,
 * intersects(Character), intersectsWithName(String)
 * getClara,
 * makeClaraDead,
 * wrapAroundWorld
 * playGameOverSound
 */

class Ghost extends Character
{
    int rmd = Clara.getRandomNumber(2);
    //Declaring int rmd and generating 2 random number for ghost direction in it. 
    int speed = Clara.getRandomNumber(5);
    //Declaring int speed and generating 5 random number for ghost speed in it. 
    boolean random = true;
    //Declaring a boolean for checking random. 
    boolean isAlive=true;
    //Declaring a boolean to check if the ghost is alive or not. 
    int deadTime = 0;
    //Declaring an int to check the deadtime of ghost. 
    boolean countDeadTime; 
    //Declaring a boolean to put the countDeadTime. 



    public void act()
    {
        movement();
        //Calling moment method. 
        killClara();
        //Calling kill clara method. 
        intersection();
        //Calling intersection method. 
    }


    public void movement()
    {
        if (random == true)

        {
            if ((rmd == 0))
            {
                setDirection("right");
            }

            if ((rmd == 1))
            {
                setDirection("left");
            }
            random = false;
        }
        //Method for ghost to take random directions. 

        if (rmd == 0 && earthFront())
        {
            setDirection("right");
        }
        //Command for ghost to take right when falling if rmd =0. 

        if (rmd == 1 && earthFront())
        {
            setDirection("left");
        }
        //Command for ghost to take left when falling if rmd =1. 

        if (!earthBelow())
        {
            setDirection("down");
        }
        //Command for ghosts to fall down if there's no earth below. 

        if (earthFront() && getDirection() == "right")
        {
            setDirection("left");
        }
        //Command for ghost to turn around and not pass through the earth.  

        if (earthFront() && getDirection() == "left")
        {
            setDirection("right");
        }
        //Command for ghost to turn around and not pass through the earth.  

        move(speed + 7);
        //Initiating ghosts to move with random speed in the range of 7 to 12. 

    }


    void killClara()
    {
        if (intersects(getClara()) && MyClara.dead==false&&isAlive==true)
        {
            MyClara.dead=true;
            makeClaraDead();
            playGameOverSound();
        }
    }
    //Method for ghosts to kill clara. 

    void intersection()
    {
        if(countDeadTime==true)
        {
            
            if(deadTime<=90)
            {
                isAlive=false;
                animateDead();
                deadTime++;
            }
            else 
            {
                isAlive=true;
                animate();
            }
        }

        if(Dot.BulletVisible==true&&intersectsWithName("Dot"))
        {
            deadTime=0;
            countDeadTime=true;
        }

    }
    //Method for ghosts to animate and reanimate if they intersects with a bullet. 

}